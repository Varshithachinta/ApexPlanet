function showMessage() {
    alert("Hello, you just clicked the button.");
}