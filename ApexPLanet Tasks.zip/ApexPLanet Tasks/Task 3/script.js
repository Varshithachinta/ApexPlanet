// ===== QUIZ =====
const quizData = [
  {
    question: "Which company developed JavaScript?",
    options: ["Netscape", "Microsoft", "Google"],
    answer: "Netscape"
  },
  {
    question: "Which method converts JSON to a JavaScript object?",
    options: ["JSON.stringify()", "JSON.parse()", "JSON.convert()"],
    answer: "JSON.parse()"
  },
  {
    question: "Which tag is used to link JavaScript to HTML?",
    options: ["<js>", "<script>", "<javascript>"],
    answer: "<script>"
  }
];

let index = 0;
let score = 0;

function loadQuestion() {
  const q = quizData[index];
  document.getElementById("question").textContent = q.question;
  const optionsDiv = document.getElementById("options");
  optionsDiv.innerHTML = "";

  q.options.forEach(opt => {
    const btn = document.createElement("button");
    btn.textContent = opt;
    btn.onclick = () => {
      if (opt === q.answer) score++;
      document.getElementById("nextBtn").style.display = "inline-block";
    };
    optionsDiv.appendChild(btn);
  });

  document.getElementById("nextBtn").style.display = "none";
  document.getElementById("scoreDisplay").textContent = "";
}

document.getElementById("nextBtn").addEventListener("click", () => {
  index++;
  if (index < quizData.length) {
    loadQuestion();
  } else {
    document.getElementById("quiz-box").innerHTML = `<h3>Quiz Completed!</h3><p>You scored ${score} out of ${quizData.length}.</p>`;
  }
});

loadQuestion();

// ===== JOKE API =====
document.getElementById("getJoke").addEventListener("click", () => {
  const display = document.getElementById("jokeDisplay");
  fetch("https://official-joke-api.appspot.com/random_joke")
    .then(res => res.json())
    .then(data => {
      display.textContent = `${data.setup} — ${data.punchline}`;
    })
    .catch(() => {
      display.textContent = "Oops! Couldn’t fetch a joke.";
    });
});
