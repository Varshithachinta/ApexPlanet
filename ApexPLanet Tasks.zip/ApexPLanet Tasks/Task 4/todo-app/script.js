const noteInput = document.getElementById('noteText');
const noteColor = document.getElementById('noteColor');
const notesUl = document.getElementById('noteList');
const themeToggle = document.getElementById('toggleMode');

let editIndex = null;

function getStoredNotes() {
  return JSON.parse(localStorage.getItem('myNotes')) || [];
}

function storeNotes(notes) {
  localStorage.setItem('myNotes', JSON.stringify(notes));
}

function renderNotes() {
  const notes = getStoredNotes();
  notesUl.innerHTML = '';
  notes.forEach((note, index) => {
    const li = document.createElement('li');
    li.style.borderLeft = `6px solid ${note.color}`;
    li.innerHTML = `
      ${note.text}
      <button class="edit-btn" onclick="editNote(${index})">Edit</button>
      <button class="delete-btn" onclick="removeNote(${index})">Delete</button>
    `;
    notesUl.appendChild(li);
  });
}

function saveOrUpdateNote() {
  const text = noteInput.value.trim();
  const color = noteColor.value;
  if (!text) return;

  const notes = getStoredNotes();
  if (editIndex !== null) {
    notes[editIndex] = { text, color };
    editIndex = null;
  } else {
    notes.push({ text, color });
  }
  storeNotes(notes);
  noteInput.value = '';
  renderNotes();
}

function removeNote(index) {
  const notes = getStoredNotes();
  notes.splice(index, 1);
  storeNotes(notes);
  renderNotes();
}

function editNote(index) {
  const notes = getStoredNotes();
  noteInput.value = notes[index].text;
  noteColor.value = notes[index].color;
  editIndex = index;
}

// Theme toggle
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('note-theme', document.body.classList.contains('dark') ? 'dark' : 'light');
});

function loadTheme() {
  if (localStorage.getItem('note-theme') === 'dark') {
    document.body.classList.add('dark');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
  renderNotes();
});
