const items = [
  { id: 1, name: "Phone", category: "Electronics", price: 99, rating: 4.5 },
  { id: 2, name: "Novel", category: "Books", price: 25, rating: 4.0 },
  { id: 3, name: "Shirt", category: "Clothing", price: 50, rating: 3.7 },
  { id: 4, name: "Laptop", category: "Electronics", price: 180, rating: 5 },
  { id: 5, name: "Notebook", category: "Books", price: 15, rating: 4.2 }
];

const categoryEl = document.getElementById('typeSelect');
const priceEl = document.getElementById('priceSelect');
const sortEl = document.getElementById('sortSelect');
const display = document.getElementById('productList');

function showProducts() {
  const selectedCategory = categoryEl.value;
  const maxPrice = Number(priceEl.value);
  const sortKey = sortEl.value;

  let filtered = items.filter(p =>
    (selectedCategory === 'All' || p.category === selectedCategory) &&
    p.price <= maxPrice
  );

  filtered.sort((a, b) => b[sortKey] - a[sortKey]);

  display.innerHTML = filtered.map(prod => `
    <div class="product-card">
      <h3>${prod.name}</h3>
      <p><strong>Category:</strong> ${prod.category}</p>
      <p><strong>Price:</strong> $${prod.price}</p>
      <p><strong>Rating:</strong> ${prod.rating}</p>
    </div>
  `).join('');
}

function switchTheme() {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme-mode', document.body.classList.contains('dark') ? 'dark' : 'light');
}

function applySavedTheme() {
  if (localStorage.getItem('theme-mode') === 'dark') {
    document.body.classList.add('dark');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  applySavedTheme();
  showProducts();
  categoryEl.addEventListener('change', showProducts);
  priceEl.addEventListener('change', showProducts);
  sortEl.addEventListener('change', showProducts);
});
